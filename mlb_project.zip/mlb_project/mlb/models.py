from django.db import models

class TeamStandings(models.Model):
    team_name = models.CharField(max_length=255)
    wins = models.PositiveIntegerField()
    losses = models.PositiveIntegerField()
    pct = models.DecimalField(max_digits=4, decimal_places=3)
    games_back = models.CharField(max_length=10)
    last_10 = models.CharField(max_length=10)
    run_differential = models.IntegerField()

    def __str__(self):
        return self.team_name

