import requests
from django.core.management.base import BaseCommand
from mlb.models import TeamStandings

class Command(BaseCommand):
    help = 'Update MLB standings from the API'

    def handle(self, *args, **kwargs):
        url = "https://statsapi.mlb.com/api/v1/standings?leagueId=103,104"
        response = requests.get(url)
        data = response.json()

        if 'records' in data:
            standings_data = data['records'][1]['teamRecords']  # Adjust index if needed

            TeamStandings.objects.all().delete()

            for team_data in standings_data:
                team = team_data['team']
                wins = team_data['leagueRecord']['wins']
                losses = team_data['leagueRecord']['losses']
                pct = team_data['leagueRecord']['pct']
                games_back = team_data['gamesBack']
                last_10 = team_data['records']['splitRecords'][8]['pct']
                run_differential = team_data['runDifferential']

                TeamStandings.objects.create(
                    team_name=team['name'],
                    wins=wins,
                    losses=losses,
                    pct=pct,
                    games_back=games_back,
                    last_10=last_10,
                    run_differential=run_differential
                )

            self.stdout.write(self.style.SUCCESS('MLB standings updated successfully'))
