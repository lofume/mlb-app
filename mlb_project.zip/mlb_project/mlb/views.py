

from django.shortcuts import render
import xml.etree.ElementTree as ET
import requests
from datetime import datetime
from .models import TeamStandings


# NEWS DATA
def format_pub_date(pub_date_str):
    # Parse the pub_date string to a datetime object
    pub_date = datetime.strptime(pub_date_str, "%a, %d %b %Y %H:%M:%S %Z")
    # Format the datetime object to the desired format
    formatted_pub_date = pub_date.strftime("%b %d, %Y")
    return formatted_pub_date

def fetch_news_from_feed():
    rss_url = "https://www.mlb.com/feeds/news/rss.xml"
    response = requests.get(rss_url)
    if response.status_code == 200:
        root = ET.fromstring(response.text)
        news_data = []
        for item in root.findall(".//item"):
            title = item.find("title").text
            link = item.find("link").text
            pub_date_str = item.find("pubDate").text
            formatted_pub_date = format_pub_date(pub_date_str)
            image_url = item.find(".//image").get("href")  
            creator = item.find(".//{http://purl.org/dc/elements/1.1/}creator").text
            
            news_data.append({
                "title": title,
                "link": link,
                "pub_date": formatted_pub_date,
                "image_url": image_url,
                "creator": creator,
            })
        return news_data
    return None

def news_list(request):
    news_data = fetch_news_from_feed()
    return render(request, 'news_list.html', {'news_data': news_data})

def home(request):
    standings = TeamStandings.objects.all()
    return render(request, 'standings.html', {'standings': standings})


